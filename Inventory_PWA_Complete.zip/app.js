function showSection(id) {
  document.querySelectorAll("section").forEach(s => s.classList.remove("active"));
  document.getElementById(id).classList.add("active");
}

document.getElementById("darkToggle").onclick = () => {
  document.body.classList.toggle("dark");
};

function addProduct() {
  const product = {
    name: pName.value,
    cost: +pCost.value,
    sell: +pSell.value,
    stock: +pStock.value
  };
  addData("products", product);
  loadProducts();
}

function loadProducts() {
  getAll("products", data => {
    const table = document.getElementById("productTable");
    table.innerHTML = "<tr><th>Name</th><th>Stock</th><th>Action</th></tr>";
    data.forEach(p => {
      table.innerHTML += `
        <tr>
          <td>${p.name}</td>
          <td>${p.stock}</td>
          <td>
            <button onclick="deleteData('products', ${p.id}); loadProducts();">Delete</button>
          </td>
        </tr>`;
    });
    populateDropdowns(data);
    updateDashboard();
  });
}

function addPurchase() {
  const id = +purchaseProduct.value;
  const qty = +purchaseQty.value;
  getAll("products", products => {
    const product = products.find(p => p.id === id);
    product.stock += qty;
    updateData("products", product);
    addData("purchases", { productId: id, qty, date: new Date() });
    loadProducts();
  });
}

function addSale() {
  const id = +saleProduct.value;
  const qty = +saleQty.value;
  getAll("products", products => {
    const product = products.find(p => p.id === id);
    if (product.stock < qty) return alert("Low stock!");
    product.stock -= qty;
    const profit = (product.sell - product.cost) * qty;
    updateData("products", product);
    addData("sales", { productId: id, qty, profit, date: new Date() });
    loadProducts();
  });
}

function updateDashboard() {
  getAll("products", products => {
    document.getElementById("totalProducts").innerText = products.length;
  });

  getAll("sales", sales => {
    const revenue = sales.reduce((a, b) => a + (b.qty || 0), 0);
    const profit = sales.reduce((a, b) => a + (b.profit || 0), 0);
    document.getElementById("totalRevenue").innerText = revenue;
    document.getElementById("totalProfit").innerText = profit;
    drawChart(sales);
  });
}

function drawChart(sales) {
  const ctx = document.getElementById("salesChart");
  new Chart(ctx, {
    type: 'bar',
    data: {
      labels: sales.map(s => new Date(s.date).toLocaleDateString()),
      datasets: [{
        label: 'Profit',
        data: sales.map(s => s.profit)
      }]
    }
  });
}

function exportCSV() {
  getAll("products", data => {
    let csv = "Name,Cost,Sell,Stock\n";
    data.forEach(p => {
      csv += `${p.name},${p.cost},${p.sell},${p.stock}\n`;
    });
    const blob = new Blob([csv]);
    const a = document.createElement("a");
    a.href = URL.createObjectURL(blob);
    a.download = "products.csv";
    a.click();
  });
}

function populateDropdowns(products) {
  purchaseProduct.innerHTML = "";
  saleProduct.innerHTML = "";
  products.forEach(p => {
    purchaseProduct.innerHTML += `<option value="${p.id}">${p.name}</option>`;
    saleProduct.innerHTML += `<option value="${p.id}">${p.name}</option>`;
  });
}
