let db;
const request = indexedDB.open("InventoryDB", 1);

request.onupgradeneeded = function(e) {
  db = e.target.result;
  db.createObjectStore("products", { keyPath: "id", autoIncrement: true });
  db.createObjectStore("sales", { keyPath: "id", autoIncrement: true });
  db.createObjectStore("purchases", { keyPath: "id", autoIncrement: true });
};

request.onsuccess = function(e) {
  db = e.target.result;
  loadProducts();
  updateDashboard();
};

function addData(store, data) {
  const tx = db.transaction(store, "readwrite");
  tx.objectStore(store).add(data);
}

function getAll(store, callback) {
  const tx = db.transaction(store, "readonly");
  const req = tx.objectStore(store).getAll();
  req.onsuccess = () => callback(req.result);
}

function updateData(store, data) {
  const tx = db.transaction(store, "readwrite");
  tx.objectStore(store).put(data);
}

function deleteData(store, id) {
  const tx = db.transaction(store, "readwrite");
  tx.objectStore(store).delete(id);
}
