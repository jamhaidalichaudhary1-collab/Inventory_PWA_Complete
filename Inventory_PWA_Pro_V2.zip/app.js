
function showSection(id){
document.querySelectorAll("section").forEach(s=>s.classList.remove("active"));
document.getElementById(id).classList.add("active");
}
function toggleDark(){document.body.classList.toggle("dark");}
function toggleLayout(){
const c=document.getElementById("layoutContainer");
c.classList.toggle("horizontal");
c.classList.toggle("vertical");
}

function addProduct(){
const file=document.getElementById("pImage").files[0];
const reader=new FileReader();
reader.onload=function(){
addData("products",{name:pName.value,cost:+pCost.value,sell:+pSell.value,stock:+pStock.value,image:reader.result});
loadProducts();
};
if(file)reader.readAsDataURL(file);
}

function loadProducts(){
getAll("products",data=>{
productList.innerHTML="";
purchaseProduct.innerHTML="";
saleProduct.innerHTML="";
data.forEach(p=>{
productList.innerHTML+=`<div class="card"><img src="${p.image}" class="product-img"><b>${p.name}</b> | Stock:${p.stock}</div>`;
purchaseProduct.innerHTML+=`<option value="${p.id}">${p.name}</option>`;
saleProduct.innerHTML+=`<option value="${p.id}">${p.name}</option>`;
});
});
}

function addPurchase(){
const id=+purchaseProduct.value;
const qty=+purchaseQty.value;
getAll("products",data=>{
const p=data.find(x=>x.id===id);
p.stock+=qty;
db.transaction("products","readwrite").objectStore("products").put(p);
addData("purchases",{productId:id,qty,date:new Date().toISOString()});
loadProducts();
});
}

function addSale(){
const id=+saleProduct.value;
const qty=+saleQty.value;
getAll("products",data=>{
const p=data.find(x=>x.id===id);
if(p.stock<qty)return alert("Low stock");
p.stock-=qty;
db.transaction("products","readwrite").objectStore("products").put(p);
const profit=(p.sell-p.cost)*qty;
addData("sales",{productId:id,qty,profit,date:new Date().toISOString()});
drawAnalytics();
loadProducts();
});
}

function drawAnalytics(){
getAll("sales",sales=>{
const ctx=document.getElementById("profitChart");
new Chart(ctx,{type:"line",data:{
labels:sales.map(s=>new Date(s.date).toLocaleDateString()),
datasets:[{label:"Profit",data:sales.map(s=>s.profit)}]
}});
});
}

function generateReport(){
const month=document.getElementById("monthFilter").value;
getAll("sales",sales=>{
const filtered=sales.filter(s=>s.date.startsWith(month));
const total=filtered.reduce((a,b)=>a+b.profit,0);
reportResult.innerHTML="Total Profit: "+total;
});
}

function backupData(){
Promise.all([new Promise(r=>getAll("products",r)),new Promise(r=>getAll("sales",r)),new Promise(r=>getAll("purchases",r))])
.then(([p,s,pu])=>{
const blob=new Blob([JSON.stringify({p,s,pu})]);
const a=document.createElement("a");
a.href=URL.createObjectURL(blob);
a.download="backup.json";
a.click();
});
}

function restoreData(e){
const reader=new FileReader();
reader.onload=function(){
const data=JSON.parse(reader.result);
clearStore("products");
clearStore("sales");
clearStore("purchases");
data.p.forEach(x=>addData("products",x));
data.s.forEach(x=>addData("sales",x));
data.pu.forEach(x=>addData("purchases",x));
loadProducts();
drawAnalytics();
};
reader.readAsText(e.target.files[0]);
}
