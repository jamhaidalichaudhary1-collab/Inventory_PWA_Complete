
let db;
const request=indexedDB.open("InventoryProDB",1);
request.onupgradeneeded=e=>{
db=e.target.result;
db.createObjectStore("products",{keyPath:"id",autoIncrement:true});
db.createObjectStore("sales",{keyPath:"id",autoIncrement:true});
db.createObjectStore("purchases",{keyPath:"id",autoIncrement:true});
};
request.onsuccess=e=>{db=e.target.result;loadProducts();drawAnalytics();};
function addData(store,data){db.transaction(store,"readwrite").objectStore(store).add(data);}
function getAll(store,cb){const r=db.transaction(store,"readonly").objectStore(store).getAll();r.onsuccess=()=>cb(r.result);}
function clearStore(store){db.transaction(store,"readwrite").objectStore(store).clear();}
